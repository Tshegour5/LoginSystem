/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.loginsystem;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class UserTest {
    
    public UserTest() {
    }

    @org.junit.jupiter.api.BeforeAll
    public static void setUpClass() throws Exception {
    }

    @org.junit.jupiter.api.AfterAll
    public static void tearDownClass() throws Exception {
    }

    @org.junit.jupiter.api.BeforeEach
    public void setUp() throws Exception {
    }

    @org.junit.jupiter.api.AfterEach
    public void tearDown() throws Exception {
    }

    /**
     * Test of authenticate method, of class User.
     */
    @org.junit.jupiter.api.Test
    public void testAuthenticate() {
        System.out.println("Testing user authentication...");
        
        // Create a user with all 5 required fields
        User instance = new User("admin", "secret123", "John", "Doe", "12345678");
        
        boolean expResult = true;
        boolean result = instance.authenticate("admin", "secret123");
        
        assertEquals(expResult, result);

    }

    /**
     * Test of getFirstName method, of class User.
     */
    @org.junit.jupiter.api.Test
    public void testGetFirstName() {
            System.out.println("testGetFirstName");
                User instance = new User("admin", "secret123", "12345678", "John", "Doe");
        assertEquals("John", instance.getFirstName());
    }

    /**
     * Test of getLastName method, of class User.
     */
    @org.junit.jupiter.api.Test
    public void testGetLastName() {
        System.out.println("testGetLastName");
                User instance = new User("admin", "secret123", "12345678", "John", "Doe");
        assertEquals("Doe", instance.getLastName());
    }

    /**
     * Test of getPhone method, of class User.
     */
    @org.junit.jupiter.api.Test
    public void testGetPhone() {
          System.out.println("testGetPhone");
                  User instance = new User("admin", "secret123", "12345678", "John", "Doe");

        assertEquals("12345678", instance.getPhone());
    } 
    
}
